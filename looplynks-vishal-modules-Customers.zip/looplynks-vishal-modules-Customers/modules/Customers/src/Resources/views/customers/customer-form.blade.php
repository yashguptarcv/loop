<form method="POST" action="{{ isset($customer) ? route('admin.customers.update', $customer->id) : route('admin.customers.store') }}">
    @csrf
    @if(isset($customer))
    @method('PUT')
    @endif

    <div class="mb-6">
        <label for="name" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Name <span class="text-red-500">*</span>
        </label>
        <input id="name"
            type="text"
            name="name"
            value="{{ old('name', $customer->name ?? '') }}"
            required
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-200 @error('name') border-red-500 dark:border-red-400 @enderror">
        @error('name')
        <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
        @enderror
    </div>

    <div class="mb-6">
        <label for="email" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Email <span class="text-red-500">*</span>
        </label>
        <input id="email"
            type="email"
            name="email"
            value="{{ old('email', $customer->email ?? '') }}"
            required
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-200 @error('email') border-red-500 dark:border-red-400 @enderror">
        @error('email')
        <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
        @enderror
    </div>

    <div class="mb-6">
        <label for="password" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            {{ isset($customer) ? 'New Password' : 'Password' }}
            @if(isset($customer))
            <span class="text-gray-500 text-xs">(leave blank to keep current password)</span>
            @else
            <span class="text-red-500">*</span>
            @endif
        </label>
        <input id="password"
            type="password"
            name="password"
            {{ !isset($customer) ? 'required' : '' }}
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-200 @error('password') border-red-500 dark:border-red-400 @enderror">
        @error('password')
        <p class="mt-1 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
        @enderror
    </div>

    <div class="mb-6">
        <label for="password_confirmation" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            {{ isset($customer) ? 'Confirm New Password' : 'Confirm Password' }}
            @if(isset($customer))
            <span class="text-gray-500 text-xs">(leave blank to keep current password)</span>
            @else
            <span class="text-red-500">*</span>
            @endif
        </label>
        <input id="password_confirmation"
            type="password"
            name="password_confirmation"
            {{ !isset($customer) ? 'required' : '' }}
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-200">
    </div>

    <div class="flex items-center justify-end space-x-3">
        <div class="mt-8 flex justify-end space-x-3">
            <x-button type="submit" class="primary" label="Update Customer" icon='' name='button' />
        </div>
    </div>
</form>