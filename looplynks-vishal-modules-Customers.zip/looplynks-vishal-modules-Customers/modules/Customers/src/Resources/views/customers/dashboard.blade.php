@extends('customers::layouts.app')

@section('content')
<div class="min-h-screen bg-gray-100">
    <!-- Header Navigation  -->
    <nav class="bg-white shadow-sm border-b">
        <div class="max-w-full mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <!-- Logo -->
                <div class="flex-shrink-0">
                    <div class="p-6 pb-4 text-2xl font-bold border-b border-primary-100 flex items-center space-x-2">
                        @php
                        $logo = fn_get_image('company_logo', 0)['url'] ?? '';
                        @endphp
                        @if($logo)
                        <img src="{{$logo}}" alt="image" width="120px" height="auto">
                        @else
                        {{fn_get_setting('general.company.name')}}
                        @endif
                    </div>
                </div>

                <!-- Centered Navigation -->
                <div class="hidden md:flex flex-1 justify-center">
                    <div class="flex items-baseline space-x-8" id="mainNav">
                        <a href="{{ route('customer.dashboard') }}" class="nav-link text-gray-500 hover:bg-gray-900 hover:text-white hover:px-4 hover:py-2 hover:rounded-full px-3 py-2 text-sm font-medium transition-all duration-200" data-nav="home">Home</a>
                        <a href="{{ route('customer.application') }}" class="nav-link text-gray-500 hover:bg-gray-900 hover:text-white hover:px-4 hover:py-2 hover:rounded-full px-3 py-2 text-sm font-medium transition-all duration-200" data-nav="application">Application</a>
                        <a href="#" class="nav-link text-gray-500 hover:bg-gray-900 hover:text-white hover:px-4 hover:py-2 hover:rounded-full px-3 py-2 text-sm font-medium transition-all duration-200" data-nav="questionnaire">Questionnaire</a>
                        <a href="#" class="nav-link text-gray-500 hover:bg-gray-900 hover:text-white hover:px-4 hover:py-2 hover:rounded-full px-3 py-2 text-sm font-medium transition-all duration-200" data-nav="accounts">Accounts</a>
                        <a href="#" class="nav-link text-gray-500 hover:bg-gray-900 hover:text-white hover:px-4 hover:py-2 hover:rounded-full px-3 py-2 text-sm font-medium transition-all duration-200" data-nav="contacts">Contacts</a>
                    </div>
                </div>

                <!-- User Profile  -->
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-3">
                        <img class="h-8 w-8 rounded-full bg-black" src="" alt="image">
                        <span class="text-sm font-medium text-gray-700">{{ $lead->name ?? 'No Name specified' }}</span>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content  -->
    <div class="mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div class="flex">
            <!-- Main Content Area  -->
            <div class="flex-1 m-8">
                <!-- Leads Header  -->
                <div class="flex items-center justify-between mb-6">
                    <div class="flex items-center space-x-8">
                        <h1 class="text-3xl font-bold text-gray-900">Customer</h1>
                        <!-- Search Bar  -->
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <svg class="h-4 w-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                                </svg>
                            </div>
                            <input type="text" placeholder="Search..." class="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-100 w-64">
                        </div>
                    </div>
                </div>

                <!-- Customer  -->
                <div class="space-y-4">

                    <div class="shadow-sm">
                        <div class="p-4 rounded-full bg-white flex items-center justify-between border-b">
                            <div class="flex items-center space-x-4">
                                <img class="h-10 w-10 rounded-full" src="" alt="image">
                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-medium text-gray-900">{{ $lead->name ?? 'No Name specified' }}</p>
                                    <p class="text-sm text-gray-500">{{ $lead->company ?? 'No company specified' }}</p>
                                </div>
                            </div>
                            <div class="flex items-center space-x-8">
                                <div class="text-sm text-gray-900">{{ $lead->created_at ?? 'No date specified' }}</div>
                                <div class="text-sm text-gray-900">{{ $lead->industries ?? 'No industries specified' }}</div>
                                <div class="text-sm text-blue-600">{{ $lead->email ?? 'No email specified' }}</div>
                                <div class="text-sm text-gray-900">{{ $lead->company ?? 'No company specified' }}</div>
                                <div class="flex items-center space-x-2">
                                    <!-- <button class="p-1 text-gray-400 hover:text-gray-600">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
                                        </svg>
                                    </button> -->
                                    <!-- <button class="p-1 text-gray-400 hover:text-gray-600">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
                                        </svg>
                                    </button>
                                    <button class="p-1 text-gray-400 hover:text-gray-600">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                                        </svg>
                                    </button> -->
                                </div>
                            </div>
                        </div>

                        <!-- Expanded Detail Content  -->
                        <div class="p-6 mt-2 grid grid-cols-1 lg:grid-cols-3 rounded-2xl bg-white gap-6">
                            <!-- Contact Details  -->
                            @include('customers::customers.components.contact_details')

                            <!-- Attachment -->
                            @include('customers::customers.components.attachments')

                            <!-- Tracking Information  -->
                            @include('customers::customers.components.tracking_information')
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const navLinks = document.querySelectorAll('.nav-link');

        // Function to set active nav link
        function setActiveNav(clickedLink) {
            navLinks.forEach(link => {
                link.classList.remove('bg-gray-900', 'text-white', 'px-4', 'py-2', 'rounded-full');
                link.classList.add('text-gray-500', 'hover:text-gray-900', 'px-3');

                // Reset to default padding if not the active link
                if (!link.classList.contains('px-4')) {
                    link.classList.add('px-3');
                }
            });

            // Add active styles to clicked link
            clickedLink.classList.remove('text-gray-500', 'hover:text-gray-900');
            clickedLink.classList.add('bg-gray-900', 'text-white', 'px-4', 'py-2', 'rounded-full');

            // Store active nav in session storage
            sessionStorage.setItem('activeNav', clickedLink.getAttribute('data-nav'));
        }

        // Add click event listeners
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                setActiveNav(this);
            });
        });

        // Check for active nav in session storage on page load
        const activeNav = sessionStorage.getItem('activeNav');
        if (activeNav) {
            const activeLink = document.querySelector(`.nav-link[data-nav="${activeNav}"]`);
            if (activeLink) {
                setActiveNav(activeLink);
            }
        }
    });
</script>
@endpush
@endsection