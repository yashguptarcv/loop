<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Dashboard')</title>

    <!-- Favicon -->
    <link rel="icon" href="{{fn_get_image('company_favicon', 0)['url'] ?? ''}}" type="image/x-icon">
    <link rel="shortcut icon" href="{{fn_get_image('company_favicon', 0)['url'] ?? ''}}" type="image/x-icon">


    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="{{ asset('css/toast.css') }}">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">

    @if(fn_get_setting('general.editor.type') == 'tinymce')
    @elseif(fn_get_setting('general.editor.type') == 'quill')
    <link href="https://cdn.jsdelivr.net/npm/quill@2.0.3/dist/quill.snow.css" rel="stylesheet" />
    @endif
     <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/gridstack@10.3.1/dist/gridstack.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/gridstack@9.3.0/dist/gridstack-h5.js"></script>
    <script src="//unpkg.com/alpinejs" defer></script>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!-- meta -->
    @yield('meta')
    @include('admin::layouts.tailwind-config')
    <!-- styles -->
    @yield('styles')
    
</head>

<body class="bg-white text-black-300 font-sans">
    <div id="toast-container" class="toast-container"></div>

    <div class="flex h-screen overflow-hidden">
        <div class="flex-1 flex flex-col overflow-hidden">
           
            <!-- Main Content -->
            <main class="">
                <div class="">
                    @yield('content')
                </div>
            </main>
        </div>
    </div>
    <x-delete-modal />
    <x-status-modal />
    <script src="{{ asset('js/toast.js') }}"></script>
    @if(fn_get_setting('general.editor.type') == 'tinymce')
    <script src="https://cdn.tiny.cloud/1/{{fn_get_setting('general.editor.api_key')}}/tinymce/8/tinymce.min.js" referrerpolicy="origin" crossorigin="anonymous"></script>
    @elseif(fn_get_setting('general.editor.type') == 'quill')
    <script src="https://cdn.jsdelivr.net/npm/quill@2.0.3/dist/quill.js"></script>
    @endif
    @yield('scripts')

    {{-- notification toggle --}}
    <script>
        // Toggle notification dropdown
        const notificationButton = document.querySelector('.relative button[aria-label="Notifications"]');
        const notificationDropdown = document.querySelector('.relative .hidden');

        if (notificationButton && notificationDropdown) {
            notificationButton.addEventListener('click', (e) => {
                e.stopPropagation();
                notificationDropdown.classList.toggle('hidden');
            });

            // Close when clicking outside
            document.addEventListener('click', (e) => {
                if (!notificationButton.contains(e.target) && !notificationDropdown.contains(e.target)) {
                    notificationDropdown.classList.add('hidden');
                }
            });
        }

        // User dropdown menu
        const userMenuButton = document.getElementById('userMenuButton');
        const userMenu = document.getElementById('userMenu');

        if (userMenuButton && userMenu) {
            userMenuButton.addEventListener('click', (e) => {
                e.stopPropagation();
                userMenu.classList.toggle('hidden');
            });

            document.addEventListener('click', (e) => {
                if (!userMenuButton.contains(e.target) && !userMenu.contains(e.target)) {
                    userMenu.classList.add('hidden');
                }
            });
        }

        // Close dropdowns when pressing Escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                notificationDropdown?.classList.add('hidden');
                userMenu?.classList.add('hidden');
            }
        });

        // Sidebar toggle for mobile
        document.addEventListener('DOMContentLoaded', () => {
            const sidebarToggle = document.getElementById('sidebarToggle');
            const sidebar = document.querySelector('aside');

            if (sidebarToggle && sidebar) {
                sidebarToggle.addEventListener('click', () => {
                    sidebar.classList.toggle('-translate-x-full');
                });
            }
        });
    </script>

   
    {{-- toast modal throgh sessions --}}
    <script>
        window.addEventListener('DOMContentLoaded', () => {
            const toast = sessionStorage.getItem('toastMessage');
            if (toast) {
                const {
                    message,
                    type,
                    title
                } = JSON.parse(toast);
                showToast(message, type, title); // Your existing toast function
                sessionStorage.removeItem('toastMessage'); // Clear after showing
            }
        });
    </script>

 

   
</body>

</html>