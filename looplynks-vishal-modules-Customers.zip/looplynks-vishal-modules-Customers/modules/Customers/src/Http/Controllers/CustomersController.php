<?php

namespace Modules\Customers\Http\Controllers;

use Illuminate\Http\Request;
use Modules\Orders\Models\Order;
use Illuminate\Routing\Controller;
use Modules\Leads\Models\LeadModel;
use Modules\Orders\Models\Transaction;
use Modules\Customers\DataView\Customers;
use Modules\Customers\DataView\LeadDataGrid;
use Modules\Customers\DataView\ApplicationGrid;
use Modules\Customers\DataView\LeadDetailsGrid;
use Modules\Customers\Models\User as ModelsUser;
use Modules\Customers\DataView\CustomerOrderGrid;
use Modules\Acl\Models\Admin;
use Modules\Customers\DataView\CustomerTransactionGrid;
use Modules\Leads\Models\Application;
use Illuminate\Support\Facades\Auth;

class CustomersController extends Controller
{
    public function index(Request $request)
    {
        $lists = fn_datagrid(Customers::class)->process();
        return view("customers::customers.index", compact('lists'));
    }

    public function dashboard()
    {
        // Get the authenticated user
        $user = Auth::guard('customer')->user();

        // Get the lead data for the current user
        $lead = LeadModel::where('user_id', $user->id)
            ->with(['status', 'source', 'assignedTo'])
            ->first();

        // Get country data if country_id exists
        $country = null;
        if (!empty($lead->country)) {
            $country = fn_get_country_data($lead->country);
        }

        return view("customers::customers.dashboard", compact('lead', 'country'));
    }

    public function applicationCustomer()
    {
        $user = Auth::guard('customer')->user();
        
        // Get lead data
        $lead = LeadModel::where('user_id', $user->id)
            ->with(['status', 'source', 'assignedTo'])
            ->first();
            
        // Get applications for the customer
        $applications = \Modules\Leads\Models\Application::where('email', $user->email)
            ->orderBy('created_at', 'desc')
            ->get();
            
        // Get country data
        $country = null;
        if (!empty($lead->country)) {
            $country = fn_get_country_data($lead->country);
        }

        return view("customers::customers.application", compact('lead', 'country', 'applications'));
    }

    public function show(ModelsUser $customer)
    {
        $lead = LeadModel::where('user_id', $customer->id)->first();
        return view("customers::customers.show", compact('customer', 'lead'));
    }

    public function edit(Request $request, $id)
    {
        $customer = ModelsUser::find($id);
        return view('customers::customers.customer-form', compact('customer'));
    }

    public function update(Request $request, $id)
    {
        $customer = ModelsUser::findOrFail($id);

        // Validation rules
        $rules = [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,' . $id,
        ];

        // Only validate password if it's provided
        if ($request->filled('password')) {
            $rules['password'] = 'required|string|min:8|confirmed';
        }

        // Validate the request
        $validatedData = $request->validate($rules);

        try {
            // Update the customer
            $customer->name = $validatedData['name'];
            $customer->email = $validatedData['email'];

            // Update password if provided
            if (isset($validatedData['password'])) {
                $customer->password = bcrypt($validatedData['password']);
            }

            $customer->save();

            return redirect()->route('admin.customers.show', $customer->id)
                ->with('success', 'Customer updated successfully');
        } catch (\Exception $e) {
            return redirect()->back()
                ->withInput()
                ->with('error', 'Error updating customer: ' . $e->getMessage());
        }
    }

    public function orders(ModelsUser $customer)
    {
        $lists = fn_datagrid(CustomerOrderGrid::class)->process();
        return view("customers::customers.show", compact('customer', 'lists'))->with('activeTab', 'orders');
    }

    public function orderEdit(ModelsUser $customer)
    {
        // $lists = fn_datagrid(CustomerOrderGrid::class)->process();
        // return view("customers::customers.show", compact('customer', 'lists'))->with('activeTab', 'orders');
    }

    public function bulkDelete(ModelsUser $customer, Request $request)
    {
        $request->validate([
            'rows' => 'required|array',
            'rows.*' => 'exists:orders,id,user_id,' . $customer->id
        ]);

        try {
            $deleted = Order::whereIn('id', $request->rows)
                ->where('user_id', $customer->id)
                ->delete();

            return response()->json([
                'success' => true,
                'message' => "Successfully deleted $deleted order(s)."
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error deleting orders: ' . $e->getMessage()
            ], 500);
        }
    }

    public function orderDelete(ModelsUser $customer, Order $order)
    {
        try {
            if ($order->user_id !== $customer->id) {
                return response()->json([
                    'success' => false,
                    'message' => 'Order does not belong to this customer.'
                ]);
            }

            $order->delete();

            return response()->json([
                'success' => true,
                'message' => 'Order deleted successfully.',
                'redirect' => route('admin.customers.show', $customer->id)
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error deleting order: ' . $e->getMessage()
            ]);
        }
    }


    public function application(ModelsUser $customer)
    {
        // $lists = LeadDataGrid::where('user_id', $customer->id)->first();
        $lists = fn_datagrid(ApplicationGrid::class)->process();
        return view("customers::customers.show", compact('customer', 'lists'))->with('activeTab', 'application');
    }
    //leadDetailsDelete

    public function applicationDetailsDelete(ModelsUser $customer, $leadId)
    {
        try {
            $application = Application::where('id', $leadId)
                ->where('email', $customer->email)
                ->firstOrFail();

            $application->delete();

            return response()->json([
                'success' => true,
                'message' => 'Application deleted successfully.',
                'redirect' => route('admin.customers.show', $customer->id)
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Application not found or you do not have permission to delete it.'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error deleting application: ' . $e->getMessage()
            ]);
        }
    }

    public function transactions(ModelsUser $customer)
    {
        $lists = fn_datagrid(CustomerTransactionGrid::class)->process();
        return view("customers::customers.show", compact('customer', 'lists'))->with('activeTab', 'transactions');
    }


    public function transactionDelete(ModelsUser $customer, Transaction $transaction)
    {
        try {
            if ($transaction->order->customer_id !== $customer->id) {
                return response()->json([
                    'success' => false,
                    'message' => 'Transaction does not belong to this customer.'
                ]);
            }

            if ($transaction->status === 'completed' || $transaction->status === 'refunded') {
                return response()->json([
                    'success' => false,
                    'message' => 'Cannot delete a completed or refunded transaction.'
                ]);
            }

            $transaction->delete();

            return response()->json([
                'success' => true,
                'message' => 'Transaction deleted successfully.'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error deleting transaction: ' . $e->getMessage()
            ]);
        }
    }


    public function lead(Request $request, ModelsUser $customer)
    {
        // Get the lead associated with this customer
        $lead = LeadModel::with(['status', 'source', 'assignedTo', 'tags', 'application', 'activities', 'notes', 'attachments'])
            ->where('user_id', $customer->id)
            ->firstOrFail();



        $perPage = fn_get_setting('general.per_page');
        $admins = Admin::get(['id', 'name']);

        // Set the active tab
        $activeTab = $request->input('tab', 'activity');

        // Handle tab-specific content loading
        if ($request->input('tab')) {
            switch ($activeTab) {
                case 'activity':
                    $items = $lead->activities()
                        ->orderBy('created_at', 'desc')
                        ->paginate($perPage);
                    return view('leads::leads.components.lead-detail-right.activity', ['items' => $items, 'lead' => $lead]);

                case 'notes':
                    $items = $lead->notes()
                        ->orderBy('created_at', 'desc')
                        ->paginate($perPage);
                    return view('leads::leads.components.lead-detail-right.notes', ['items' => $items, 'lead' => $lead]);

                case 'files':
                    $items = $lead->attachments()
                        ->orderBy('created_at', 'desc')
                        ->paginate($perPage);
                    return view('leads::leads.components.lead-detail-right.files', ['items' => $items, 'lead' => $lead]);

                case 'application':
                    $items = $lead->application()
                        ->orderBy('created_at', 'desc')
                        ->paginate($perPage);

                    return view('leads::leads.components.lead-detail-right.application', ['items' => $items, 'lead' => $lead]);
                default:
                    return abort(400);
            }
        }

        // Initial tab load
        $viewData = [
            'lead' => $lead,
            'admins' => $admins,
        ];

        $viewData['activities'] = $lead->activities()
            ->orderBy('created_at', 'desc')
            ->paginate($perPage);

        return view('leads::leads.lead-details', $viewData);
    }
}
