<?php

namespace Modules\Customers\DataView;

use Illuminate\Http\Request;
use Modules\DataView\ColumnTypes\Integer;
use Modules\DataView\DataGrid;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Modules\Customers\Models\User;

class ApplicationGrid extends DataGrid
{
    protected $primaryColumn = "id";
    protected $itemsPerPage = 10;
    protected $sortOrder = 'desc';

    /**
     * Prepare query builder.
     *
     * @return \Illuminate\Database\Query\Builder
     */
    public function prepareQueryBuilder()
    {
        $query = DB::table('applications')
            ->select(
                'id',
                'full_name',
                'mobile',
                'email',
                'organization',
                'designation',
                // 'billing_address',
            );

        // Filter by customer's email from request parameter if available
        if (request()->route('customer')) {
            $customer = request()->route('customer');
            $customerEmail = is_object($customer) ? $customer->email : User::find($customer)->email;
            $query->where('email', $customerEmail);
        }

        return $query;
    }

    /**
     * Add columns.
     *
     * @return void
     */
    public function prepareColumns()
    {
        $this->addColumn([
            'index' => 'id',
            'label' => 'ID',
            'type' => 'integer',
            'searchable' => false,
            'filterable' => false,
            'sortable' => true,
        ]);

        $this->addColumn([
            'index' => 'full_name',
            'label' => 'Name',
            'type' => 'string',
            'searchable' => true,
            'filterable' => true,
            'sortable' => true,
        ]);

        $this->addColumn([
            'index' => 'email',
            'label' => 'Email',
            'type' => 'string',
            'searchable' => true,
            'filterable' => true,
            'sortable' => true,
        ]);

        $this->addColumn([
            'index' => 'mobile',
            'label' => 'Mobile',
            'type' => 'integer',
            'searchable' => true,
            'filterable' => true,
            'sortable' => true,
        ]);

        $this->addColumn([
            'index' => 'designation',
            'label' => 'Designation',
            'type' => 'string',
            'searchable' => true,
            'filterable' => true,
            'sortable' => true,
        ]);

        $this->addColumn([
            'index' => 'organization',
            'label' => 'Organization',
            'type' => 'string',
            'searchable' => true,
            'filterable' => true,
            'sortable' => true,
        ]);
 
        // $this->addColumn([
        //     'index' => 'billing_address',
        //     'label' => 'Billing Address',
        //     'type' => 'string',
        //     'searchable' => true,
        //     'filterable' => true,
        //     'sortable' => true,
        // ]);
    }

    /**
     * Prepare actions.
     *
     * @return void
     */
    public function prepareActions()
    {
        // if (bouncer()->hasPermission('admin.settings.countries.edit')) {
        //     $this->addAction([
        //         'icon' => 'edit',
        //         'title' => 'Edit',
        //         'method' => 'GET',
        //         'is_popup'  => true,
        //         'url' => function ($row) {
        //             return route('admin.settings.countries.edit', $row->id);
        //         },
        //     ]);
        // }

        if (bouncer()->hasPermission('admin.customers.application.delete')) {
            $this->addAction([
                'icon' => 'delete',
                'title' => 'Delete',
                'method' => 'DELETE',
                'url' => function ($row) {
                    $customer = request()->route('customer');
                    $customerId = is_object($customer) ? $customer->id : $customer;
                    
                    return route('admin.customers.application.delete', [
                        'customer' => $customerId,
                        'application' => $row->id
                    ]);
                },
            ]);
        }
    }

    /**
     * Prepare mass actions.
     *
     * @return void
     */
    public function prepareMassActions()
    {
        // if (bouncer()->hasPermission('admin.customers.bulk-delete')) {
        //     $this->addMassAction([
        //         'icon' => 'delete',
        //         'title' => 'Bulk Delete',
        //         'method' => 'POST',
        //         'action' => 'text-red-600 bg-red-100',
        //         'url' => 'admin.customers.bulk-delete',
        //     ]);
        // }

        // if (bouncer()->hasPermission('admin.customers.create')) {
        //     $this->addMassAction([
        //         'icon' => 'add',
        //         'title' => 'Create Customer',
        //         'method' => 'GET',
        //         'action' => 'text-amber-100 bg-primary-100',
        //         'url' => 'admin.customers.create',
        //     ]);
        // }
    }
}
