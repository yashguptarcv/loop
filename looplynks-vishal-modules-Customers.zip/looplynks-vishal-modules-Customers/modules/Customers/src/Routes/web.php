<?php

use Modules\Customers\Http\Controllers\TransactionController;
use Modules\Customers\Http\Controllers\OrderController;
use Illuminate\Support\Facades\Route;
use Modules\Customers\Http\Controllers\HomeController;
use Modules\Customers\Http\Controllers\CustomersController;
use Modules\Customers\Http\Controllers\Auth\AuthCustomerController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your module. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix(config('core::prefix.admin'))->middleware('web')->name('admin.')->group(function () {
    // Dashboard route moved outside admin middleware
    
    Route::middleware(['admin.auth', 'admin.permission'])->group(function () {
        Route::resource('customers', CustomersController::class);
        Route::post('/customers/bulk-delete', [CustomersController::class, 'bulkDelete'])->name('customers.bulk-delete');
        
        // Nested routes for customer orders 
        Route::get('/customers/{customer}/orders', [CustomersController::class, 'orders'])->name('customers.orders');
        Route::delete('/customers/{customer}/orders/{order}', [CustomersController::class, 'orderDelete'])->name('customers.orders.delete');
     
        // Nested routes for customer transactions
        Route::get('/customers/{customer}/transactions', [CustomersController::class, 'transactions'])->name('customers.transactions');
        Route::delete('/customers/{customer}/transaction/{transaction}', [CustomersController::class, 'transactionDelete'])->name('customers.transaction.delete');

        Route::get('/customers/{customer}/lead', [CustomersController::class, 'lead'])->name('customers.lead');
        
        Route::get('/customers/{customer}/application', [CustomersController::class, 'application'])->name('customers.application');
        Route::delete('/customers/{customer}/application/{application}', [CustomersController::class, 'applicationDetailsDelete'])->name('customers.application.delete');

        
    });
});

Route::prefix('customer')->middleware('web')->name('customer.')->group(function () {
    Route::get('/login', [AuthCustomerController::class, 'showLogin'])->name('login.form');
    Route::post('/login', [AuthCustomerController::class, 'login'])->name('login');
    Route::post('/logout', [AuthCustomerController::class, 'logout'])->name('logout');
    
    // Customer application routes
    Route::middleware(['customer'])->group(function () {
        Route::get('/application', [CustomersController::class, 'applicationCustomer'])->name('application');
    });
    
    // Customer profile routes
    Route::get('/edit/{id}', [\Modules\Customers\Http\Controllers\CustomersController::class, 'edit'])->name('edit');
    Route::put('/{lead}', [\Modules\Customers\Http\Controllers\CustomersController::class, 'update'])->name('update');

    Route::get('/dashboard', [CustomersController::class, 'dashboard'])->name('dashboard');
    Route::get('/application', [CustomersController::class, 'applicationCustomer'])->name('application');

});





// HomeController will be generated automatically by the module generator 

// HomeController will be generated automatically by the module generator 