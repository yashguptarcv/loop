@extends('customers::layouts.app')

@section('content')
<div class="min-h-screen bg-gray-100">
    <!-- Header Navigation  -->
    <nav class="bg-white shadow-sm border-b">
        <div class="max-w-full mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <!-- Logo -->
                <div class="flex-shrink-0">
                    <div class="p-6 pb-4 text-2xl font-bold border-b border-primary-100 flex items-center space-x-2">
                        @php
                        $logo = fn_get_image('company_logo', 0)['url'] ?? '';
                        @endphp
                        @if($logo)
                        <img src="{{$logo}}" alt="image" width="120px" height="auto">
                        @else
                        {{fn_get_setting('general.company.name')}}
                        @endif
                    </div>
                </div>

                <!-- Centered Navigation -->
                <div class="hidden md:flex flex-1 justify-center">
                    <div class="flex items-baseline space-x-8" id="mainNav">
                        <a href="{{ route('customer.dashboard') }}" class="nav-link text-gray-500 hover:bg-gray-900 hover:text-white hover:px-4 hover:py-2 hover:rounded-full px-3 py-2 text-sm font-medium transition-all duration-200" data-nav="home">Home</a>
                        <a href="{{ route('customer.application') }}" class="nav-link text-gray-500 hover:bg-gray-900 hover:text-white hover:px-4 hover:py-2 hover:rounded-full px-3 py-2 text-sm font-medium transition-all duration-200" data-nav="application">Application</a>
                        <a href="#" class="nav-link text-gray-500 hover:bg-gray-900 hover:text-white hover:px-4 hover:py-2 hover:rounded-full px-3 py-2 text-sm font-medium transition-all duration-200" data-nav="questionnaire">Questionnaire</a>
                        <a href="#" class="nav-link text-gray-500 hover:bg-gray-900 hover:text-white hover:px-4 hover:py-2 hover:rounded-full px-3 py-2 text-sm font-medium transition-all duration-200" data-nav="accounts">Accounts</a>
                        <a href="#" class="nav-link text-gray-500 hover:bg-gray-900 hover:text-white hover:px-4 hover:py-2 hover:rounded-full px-3 py-2 text-sm font-medium transition-all duration-200" data-nav="contacts">Contacts</a>
                    </div>
                </div>

                <!-- User Profile  -->
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-3">
                        <img class="h-8 w-8 rounded-full bg-black" src="" alt="image">
                        <span class="text-sm font-medium text-gray-700">{{ $customer->name ?? 'No Name specified' }}</span>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content  -->
    <div class="mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div class="flex">
            <!-- Main Content Area  -->
            <div class="flex-1 m-8">
                <!-- Back button -->
                <div class="mb-6">
                    <a href="{{ route('admin.customers.application', $customer->id) }}" class="inline-flex items-center text-blue-600 hover:text-blue-800">
                        <svg class="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                        </svg>
                        Back to Applications
                    </a>
                </div>

                <!-- Application Header -->
                <div class="bg-white shadow-sm rounded-lg p-6 mb-6">
                    <h1 class="text-2xl font-bold text-gray-900 mb-2">Orders for Application</h1>
                    <div class="text-gray-600">
                        <p><span class="font-medium">Name:</span> {{ $application->full_name }}</p>
                        <p><span class="font-medium">Organization:</span> {{ $application->organization ?? 'N/A' }}</p>
                        <p><span class="font-medium">Email:</span> {{ $application->email }}</p>
                        <p><span class="font-medium">Mobile:</span> {{ $application->mobile }}</p>
                    </div>
                </div>

                <!-- Orders List -->
                <div class="bg-white shadow-sm rounded-lg overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h2 class="text-lg font-medium text-gray-900">Order History</h2>
                    </div>
                    
                    @if($orders->count() > 0)
                        <ul class="divide-y divide-gray-200">
                            @foreach($orders as $order)
                                <li class="px-6 py-4 hover:bg-gray-50">
                                    <div class="flex items-center justify-between">
                                        <div>
                                            <h3 class="text-sm font-medium text-blue-600">Order #{{ $order->id }}</h3>
                                            <p class="text-sm text-gray-500">Date: {{ $order->created_at->format('M d, Y') }}</p>
                                            <p class="text-sm text-gray-500">Status: 
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                    @if($order->status === 'completed') bg-green-100 text-green-800
                                                    @elseif($order->status === 'processing') bg-yellow-100 text-yellow-800
                                                    @elseif($order->status === 'cancelled') bg-red-100 text-red-800
                                                    @else bg-gray-100 text-gray-800 @endif">
                                                    {{ ucfirst($order->status) }}
                                                </span>
                                            </p>
                                        </div>
                                        <div class="text-right">
                                            <p class="text-sm font-medium text-gray-900">Total: ${{ number_format($order->total, 2) }}</p>
                                            <a href="#" class="text-sm text-blue-600 hover:text-blue-800">View Details</a>
                                        </div>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    @else
                        <div class="px-6 py-8 text-center">
                            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                            </svg>
                            <h3 class="mt-2 text-sm font-medium text-gray-900">No orders found</h3>
                            <p class="mt-1 text-sm text-gray-500">This application doesn't have any orders yet.</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const navLinks = document.querySelectorAll('.nav-link');

        // Function to set active nav link
        function setActiveNav(clickedLink) {
            navLinks.forEach(link => {
                link.classList.remove('bg-gray-900', 'text-white', 'px-4', 'py-2', 'rounded-full');
                link.classList.add('text-gray-500', 'hover:text-gray-900', 'px-3');

                // Reset to default padding if not the active link
                if (!link.classList.contains('px-4')) {
                    link.classList.add('px-3');
                }
            });

            // Add active styles to clicked link
            clickedLink.classList.remove('text-gray-500', 'hover:text-gray-900');
            clickedLink.classList.add('bg-gray-900', 'text-white', 'px-4', 'py-2', 'rounded-full');

            // Store active nav in session storage
            sessionStorage.setItem('activeNav', clickedLink.getAttribute('data-nav'));
        }

        // Add click event listeners
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                setActiveNav(this);
                window.location.href = this.href;
            });
        });

        // Set active nav on page load
        const activeNav = sessionStorage.getItem('activeNav');
        if (activeNav) {
            const activeLink = document.querySelector(`.nav-link[data-nav="${activeNav}"]`);
            if (activeLink) {
                setActiveNav(activeLink);
            }
        }
    });
</script>
@endpush
@endsection
