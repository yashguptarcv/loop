@extends('customers::layouts.app')

@section('content')
<div class="min-h-screen bg-gray-100">
    <!-- Header Navigation  -->
    <nav class="bg-white shadow-sm border-b">
        <div class="max-w-full mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <!-- Logo -->
                <div class="flex-shrink-0">
                    <div class="p-6 pb-4 text-2xl font-bold border-b border-primary-100 flex items-center space-x-2">
                        @php
                        $logo = fn_get_image('company_logo', 0)['url'] ?? '';
                        @endphp
                        @if($logo)
                        <img src="{{$logo}}" alt="image" width="120px" height="auto">
                        @else
                        {{fn_get_setting('general.company.name')}}
                        @endif
                    </div>
                </div>

                <!-- Centered Navigation -->
                <div class="hidden md:flex flex-1 justify-center">
                    <div class="flex items-baseline space-x-8" id="mainNav">
                        <a href="{{ route('customer.dashboard') }}" class="nav-link text-gray-500 hover:bg-gray-900 hover:text-white hover:px-4 hover:py-2 hover:rounded-full px-3 py-2 text-sm font-medium transition-all duration-200" data-nav="home">Home</a>
                        <a href="{{ route('customer.application') }}" class="nav-link text-gray-500 hover:bg-gray-900 hover:text-white hover:px-4 hover:py-2 hover:rounded-full px-3 py-2 text-sm font-medium transition-all duration-200" data-nav="application">Application</a>
                        <a href="#" class="nav-link text-gray-500 hover:bg-gray-900 hover:text-white hover:px-4 hover:py-2 hover:rounded-full px-3 py-2 text-sm font-medium transition-all duration-200" data-nav="questionnaire">Questionnaire</a>
                        <a href="#" class="nav-link text-gray-500 hover:bg-gray-900 hover:text-white hover:px-4 hover:py-2 hover:rounded-full px-3 py-2 text-sm font-medium transition-all duration-200" data-nav="accounts">Accounts</a>
                        <a href="#" class="nav-link text-gray-500 hover:bg-gray-900 hover:text-white hover:px-4 hover:py-2 hover:rounded-full px-3 py-2 text-sm font-medium transition-all duration-200" data-nav="contacts">Contacts</a>
                    </div>
                </div>

                <!-- User Profile  -->
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-3">
                        <img class="h-8 w-8 rounded-full bg-black" src="" alt="image">
                        <span class="text-sm font-medium text-gray-700">{{ $lead->name ?? 'No Name specified' }}</span>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content  -->
    <div class="mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div class="flex">
            <!-- Main Content Area  -->
            <div class="flex-1 m-8">
                <!-- Applications Section -->
                <div class="bg-white shadow rounded-lg p-6 mb-8">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-2xl font-bold text-gray-900">My Applications</h2>
                        
                    </div>
                    
                    <!-- Applications List -->
                    @include('customers::customers.components.applications')
                </div>        
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const navLinks = document.querySelectorAll('.nav-link');

        // Function to set active nav link
        function setActiveNav(clickedLink) {
            navLinks.forEach(link => {
                link.classList.remove('bg-gray-900', 'text-white', 'px-4', 'py-2', 'rounded-full');
                link.classList.add('text-gray-500', 'hover:text-gray-900', 'px-3');

                // Reset to default padding if not the active link
                if (!link.classList.contains('px-4')) {
                    link.classList.add('px-3');
                }
            });

            // Add active styles to clicked link
            clickedLink.classList.remove('text-gray-500', 'hover:text-gray-900');
            clickedLink.classList.add('bg-gray-900', 'text-white', 'px-4', 'py-2', 'rounded-full');

            // Store active nav in session storage
            sessionStorage.setItem('activeNav', clickedLink.getAttribute('data-nav'));
        }

        // Add click event listeners
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                setActiveNav(this);
            });
        });

        // Check for active nav in session storage on page load
        const activeNav = sessionStorage.getItem('activeNav');
        if (activeNav) {
            const activeLink = document.querySelector(`.nav-link[data-nav="${activeNav}"]`);
            if (activeLink) {
                setActiveNav(activeLink);
            }
        }
    });
</script>
@endpush
@endsection